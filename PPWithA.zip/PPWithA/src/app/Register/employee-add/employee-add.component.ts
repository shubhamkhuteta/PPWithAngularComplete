import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { Customer } from 'src/app/Models/Customer';
import { MyServiceService } from 'src/app/Service/my-service.service';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  createdCustomer:Customer;
  createdTransaction:Transactions;
  createdFlag:boolean=false;
  router:Router;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }


  add(data:any){
    data.caccount=Math.floor(Math.random() * 10) + 4326 
    let tid=Math.floor(Math.random() * 10) + 7985 ;
    data.cbalance=3000;
    this.createdCustomer=new Customer(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    this.service.add(this.createdCustomer);
    this.createdTransaction=new Transactions(tid,data.caccount,0,data.cbalance,"Accoun Creation");
    this.service.addTransaction(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+data.caccount);
    this.createdFlag=true;
    this.router.navigate(['app-employee-list']);
  }

  ngOnInit(){
  }

}
